package com.capgemini.dth.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import javax.naming.NamingException;

import com.capgemini.dth.bean.Customer;
import com.capgemini.dth.exception.Dthexception;
import com.capgemini.dth.utility.DbConnection;




public class DthdaoImp implements Dthdao {
	@Override
	public Customer getCustomerbyId(String id) throws Dthexception,
			SQLException, NamingException {
		Connection connect=DbConnection.getConnection();
		Statement stmt=connect.createStatement();  
			Customer csp=new Customer();
		  String qry="Select * from subscriber_account_details where mobile_number=?";
		PreparedStatement stat=connect.prepareStatement(qry);
		 Long n=Long.parseLong(id);
				System.out.println(n+">>");
			  stat.setLong(1,n);
			  System.out.println("hele1  "+stat);
			  ResultSet rs=stat.executeQuery();
			  System.out.println(rs+" "+ "hello1resukt set");
				 if(rs.next()){
					  long sid=rs.getLong("subscriber_ID");	 
					  String pid=rs.getString("package_id");
					 float fp=rs.getFloat("account_balance");
					 Date d=rs.getDate("rechargedate");
					 System.out.println(sid+" "+pid+" "+fp);
					 
					 csp=new Customer(sid,id,pid,fp,d);
		  System.out.println(csp+"object>>>>>>>>>>>>>>>>");
				 }
				 else{
					 System.out.println("false");
				 }
		  return csp;
}
	
	
	public boolean update(Customer cst) throws Dthexception, NamingException, SQLException{
		Connection connect=DbConnection.getConnection();
		Statement stmt=connect.createStatement();  
			Customer csp=new Customer();
	String qry="INSERT INTO subscriber_account_details VALUES(?,?,?,?,?)";
	int resAffected=0;
	try(PreparedStatement stmt1=connect.prepareStatement(qry);)
		{
		stmt1.setLong(1, csp.getNum());
		stmt1.setString(2,csp.getMobno());
		stmt1.setString(3,csp.getPid());
		stmt1.setFloat(4,csp.getBalance());
		stmt1.setDate(5, (java.sql.Date) csp.getDate());
		resAffected=stmt1.executeUpdate();
		}
	catch (SQLException e)
		{
		throw new Dthexception("Problem in Updating data"+e);
		}
	return (resAffected==1)?true : false;
}
}
		
		
		
		
		
		
	

