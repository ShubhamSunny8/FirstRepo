package com.capgemini.dth.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dth.bean.Customer;
import com.capgemini.dth.dao.Dthdao;
import com.capgemini.dth.dao.DthdaoImp;
import com.capgemini.dth.exception.Dthexception;


/**
 * Servlet implementation class DataSkyController
 */
@WebServlet("*.obj")
public class DataSkyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataSkyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String target="";
		String listall = "sucess.jsp";
		String search = "search.jsp";
		String targetError = "error.jsp";
		String targetHome = "index.jsp";
		Dthdao Service =new DthdaoImp();
		HttpSession session=request.getSession(true);
		String path = request.getServletPath().trim();
		System.out.println(path);
		switch (path) {
		
		case "/viewall.obj":
			String s=request.getParameter("number");
			//System.out.println("inside controller>> "+s);
			 Customer custList1=new Customer();
			 try {
				 //System.out.println(custList1);
				custList1=Service.getCustomerbyId(s);
				System.out.println("hello herre2");
				System.out.println(custList1.getMobno()+" "+" "+custList1.getDate()+" "+" "+custList1.getBalance());
				ArrayList a=new ArrayList();
				a.add(custList1);
				session.setAttribute("a", a);
				target = search;
			} catch (Dthexception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (NamingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
					 
			 break;

			

		case "/recharge.obj":
			try {
			Customer custList2 = null;
			String s1=request.getParameter("numbe");
			float re=Float.parseFloat(s1);
			String s2=request.getParameter("number");
			custList2.getNum();
			//custList1=Service.getCustomerbyId(s1);
			
			
			boolean b=Service.update(custList2);
				
				
			} catch (Dthexception | SQLException | NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			target = listall;
			break;
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		
		dispatcher.forward(request, response);	
	}
	
	}


