package com.cg.ars.daos;

import java.time.LocalDate;
import java.util.ArrayList;


import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.exceptions.AirlineException;

public interface FlightInfoDao {

	
	//userService
	public ArrayList<String> getDepCityList() throws AirlineException;
	
	//userService
	public ArrayList<String> getArrCityList() throws AirlineException;
	
	//userService and executiveService
	public ArrayList<LocalDate> getDepDateList() throws AirlineException;
		
	//adminService
	public boolean createNewFlight(FlightInfoBean flightBean) throws AirlineException;
	
	//userService
	public ArrayList<FlightInfoBean> 
	getFlightList(String depCity,String arrCity, LocalDate depDate) throws AirlineException;
	
	
	//executiveService and userService
	public FlightInfoBean getFlightDetailsOnId(int flightNo)
			throws AirlineException;
	
	
	//executiveService
	public ArrayList<FlightInfoBean> getFlightList(LocalDate startDepDate, LocalDate endDepDate)
			throws AirlineException;
	
	//userService
	public boolean updateSeatsOnBooking(int flightNo, String classType, int noOfPassengers) 
			throws AirlineException;
	
	//userService
		public boolean updateSeatsOnCancellation(int flightNo, String classType, int noOfPassengers) 
				throws AirlineException;
		
	//adminService
	public boolean removeFlight(int flightNo) throws AirlineException;
	
	//adminService
	public boolean updateArrTime(int flightNo,String arrTime)
			throws AirlineException;
	
	//adminService
	public boolean updateDepTime(int flightNo,String depTime)
			throws AirlineException;
	
	//adminService
	public boolean updateArrDate(int flightNo,LocalDate arrDate)
			throws AirlineException;
	
	//adminService
	public boolean updateDepDate(int flightNo,LocalDate depDate) 
			throws AirlineException;
	
	//adminService
	public boolean updateFirstSeats(int flightNo,int firstSeats) 
			throws AirlineException;
	
	//adminService
	public boolean updateBussSeats(int flightNo,int bussSeats) 
			throws AirlineException;
	
}
