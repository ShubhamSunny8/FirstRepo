package com.cg.ars.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;


import org.apache.log4j.Logger;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.util.ConnectionUtil;

public class FlightInfoDaoImpl implements FlightInfoDao {

	
private Connection connect = null;
static Logger myLogger = Logger.getLogger("myLogger");
	
	public FlightInfoDaoImpl() throws AirlineException {
		
		ConnectionUtil conn = new ConnectionUtil();
		connect = conn.getConnection();
		myLogger.info("Connection procured in FlightInfoDaoImpl().");	//logger message
	}
	
	//validation methods
	//validate depCity...userService
	@Override
	public ArrayList<String> getDepCityList() throws AirlineException {
		
		ArrayList<String> depCityList = new ArrayList<>();
		
		  myLogger.info("Execution in getDepCityList()."); //logger message
		
		String qry = "select depCity from flightInfo";
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
				ResultSet rs = stmt.executeQuery();
			){
			    myLogger.info("Query execution: "+ qry); //logger message
				while(rs.next()){
				String depCity = rs.getString("depCity");
				
				depCityList.add(depCity);
				
				}
				} catch (SQLException e) {
					 myLogger.error("Exception from getDepCityList()", e); //logger message
					throw new AirlineException("Probelm in  getDepCityList()!!!",e);
				}
			return depCityList;
		
	}

	//validate arrCity...userService
	@Override
	public ArrayList<String> getArrCityList() throws AirlineException {
		
		ArrayList<String> arrCityList = new ArrayList<>();
		
		  myLogger.info("Execution in getArrCityList()."); //logger message
			
		
		String qry = "select arrCity from flightInfo";
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
				ResultSet rs = stmt.executeQuery();
			){
				
				myLogger.info("Query execution: "+ qry); //logger message
				while(rs.next()){
				String arrCity = rs.getString("arrCity");
				
				arrCityList.add(arrCity);
				
				}
				} catch (SQLException e) {
					myLogger.error("Exception from getArrCityList()", e); //logger message
					throw new AirlineException("Probelm in getArrCityList() !!!",e);
				}
			return arrCityList;
	}

	
	//to validate depDate...userService and executiveService
	@Override
	public ArrayList<LocalDate> getDepDateList() throws AirlineException {
		
		ArrayList<LocalDate> depDateList = new ArrayList<>();
		
		 myLogger.info("Execution in getDepDateList()."); //logger message
		
		String qry = "select depDate from flightInfo";
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
				ResultSet rs = stmt.executeQuery();
			){
				
				myLogger.info("Query execution: "+ qry); //logger message
				while(rs.next()){
				LocalDate depDate = rs.getDate("depDate").toLocalDate();
				
				depDateList.add(depDate);
				
				}
				} catch (SQLException e) {
					myLogger.error("Exception from getDepDateList()", e); //logger message
					throw new AirlineException("Probelm in getDepDateList()  !!!",e);
				}
			return depDateList;
		
	}

	
	//create New Flight...admin service
	@Override
	public boolean createNewFlight(FlightInfoBean flightBean)
			throws AirlineException {
		
		 myLogger.info("Execution in createNewFlight()."); //logger message
		
		String qry = "insert into flightInfo values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		int recAffected = 0;
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			){
			    
				stmt.setInt(1, flightBean.getFlightNo());
				stmt.setString(2, flightBean.getAirline());
				stmt.setString(3, flightBean.getDepCity());
				stmt.setString(4, flightBean.getArrCity());
				stmt.setDate(5, Date.valueOf(flightBean.getDepDate()));
				stmt.setDate(6, Date.valueOf(flightBean.getArrDate()));
				stmt.setString(7, flightBean.getDepTime());
				stmt.setString(8, flightBean.getArrTime());
				stmt.setInt(9, flightBean.getFirstSeats());
				stmt.setInt(10, flightBean.getFirstSeatsAvailable());
				stmt.setFloat(11, flightBean.getFirstSeatFare());
				stmt.setInt(12, flightBean.getBussSeats());
				stmt.setInt(13, flightBean.getBussSeatsAvailable());
				stmt.setFloat(14, flightBean.getBussSeatFare());
				
				recAffected = stmt.executeUpdate();	
				myLogger.info("Query execution: "+ qry); //logger message
	} catch(Exception e){
		
		myLogger.error("Exception from createNewFlight()", e); //logger message
		throw new AirlineException("Problem in createNewFlight(FlightInfoBean flightBean)", e);
	}
		return recAffected > 0 ? true : false;
	}

	
	
	//retrieve flight details...users service
	@Override
	public ArrayList<FlightInfoBean> getFlightList(String depCity,
			String arrCity, LocalDate depDate) throws AirlineException {
	
		
		ArrayList<FlightInfoBean> flightList = new ArrayList<>();
		 
		myLogger.info("Execution in getFlightList()."); //logger message
			
		FlightInfoBean flightBean = null;
		
		String qry = "select * from flightInfo where depCity=? AND arrCity=? AND depDate=?";
		
		
		ResultSet rs = null;
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			){
			    
				stmt.setString(1, depCity);
				stmt.setString(2, arrCity);
				stmt.setDate(3, Date.valueOf(depDate));
			
				rs = stmt.executeQuery();
				myLogger.info("Query execution: "+ qry); //logger message
					while(rs.next())
					{
						int flightNo = rs.getInt("flightNo");
						String airline = rs.getString("airline");
						LocalDate arrDate = rs.getDate("arrDate").toLocalDate();
						String depTime = rs.getString("depTime");
						String arrTime = rs.getString("arrTime");
						int firstSeats = rs.getInt("firstSeats"); 
						float firstSeatFare = rs.getFloat("firstSeatFare");
						int firstSeatsAvailable = rs.getInt("firstSeatsAvailable");
						int bussSeats = rs.getInt("bussSeats");
						float bussSeatFare = rs.getFloat("bussSeatFare");
						int bussSeatsAvailable = rs.getInt("bussSeatsAvailable");
						
						flightBean = new FlightInfoBean(flightNo, airline, depCity, arrCity,
															depDate, arrDate, depTime, arrTime,
															firstSeats, firstSeatFare, firstSeatsAvailable,
															bussSeats, bussSeatFare, bussSeatsAvailable);
						flightList.add(flightBean);
					}
				}
			catch (SQLException e) {
				myLogger.error("Exception from getFlightList()", e); //logger message
				throw new AirlineException("Problem in getFlightList()",e);
		} finally {
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					throw new AirlineException("Problem in closing Result Set", e);
				}
			}
		}
		return flightList;
	}

	
	//update seats on successful booking...user service
	@Override
	public boolean updateSeatsOnBooking(int flightNo, String classType,
			 int noOfPassengers) throws AirlineException {
		
		int recAffected = 0;
		String qry = null;
		
		myLogger.info("Execution in updateSeatsOnBooking()."); //logger message
		
		if("BUSINESS".equals(classType)){
			qry="update flightInfo set bussSeatsAvailable = bussSeatsAvailable-? where flightNo=?";
		} else if("FIRST".equals(classType)){
			qry="update flightInfo set firstSeatsAvailable = firstSeatsAvailable-? where flightNo=?";
		}
		
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					
						stmt.setInt(1, noOfPassengers);
						stmt.setInt(2, flightNo);
					
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
					
				}
			catch (SQLException e) {	
				
				myLogger.error("Exception from updateSeatsOnBooking()", e); //logger message
				throw new AirlineException("Problem in updateSeatsOnBooking()!!!", e);
		}
			return recAffected > 0 ? true : false;
	}
	

	// update seats on cancellation...user service
	@Override
	public boolean updateSeatsOnCancellation(int flightNo, String classType,
			int noOfPassengers) throws AirlineException {
		
		int recAffected = 0;
		String qry = null;
		myLogger.info("Execution in updateSeatsOnCancellation()."); //logger message
		
		
		if("FIRST".equals(classType)){
			qry="update flightInfo set firstSeatsAvailable = firstSeatsAvailable+? where flightNo=?";
		} else if("BUSINESS".equals(classType)){
			qry="update flightInfo set bussSeatsAvailable = bussSeatsAvailable+? where flightNo=?";
		}
		
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					
						stmt.setInt(1, noOfPassengers);
						stmt.setInt(2, flightNo);
					
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from updateSeatsOnCancellation()", e); //logger message
				throw new AirlineException("Problem in  updateSeatsOnCancellation()!!!", e);
		}
			return recAffected > 0 ? true : false;
		
	}
	
	
	//get flight details on Id...used by executive/ admin
	@Override
	public FlightInfoBean getFlightDetailsOnId(int flightNo)
			throws AirlineException {
		
		FlightInfoBean flightBean = null;
		
		myLogger.info("Execution in getFlightDetailsOnId()."); //logger message
		
		
		String qry="SELECT * FROM flightInfo WHERE flightNo=?";
		ResultSet rs = null;
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			) {
				stmt.setInt(1, flightNo);
				rs = stmt.executeQuery();
				myLogger.info("Query execution: "+ qry); //logger message
					
				while(rs.next()){
					
					String airline = rs.getString("airline");
					String depCity = rs.getString("depCity"); 
					String arrCity = rs.getString("arrCity");
					LocalDate depDate = rs.getDate("depDate").toLocalDate();
					LocalDate arrDate = rs.getDate("arrDate").toLocalDate();
					String depTime = rs.getString("depTime");
					String arrTime = rs.getString("arrTime");
					int firstSeats = rs.getInt("firstSeats");
					float firstSeatFare = rs.getFloat("firstSeatFare");
					int firstSeatsAvailable = rs.getInt("firstSeatsAvailable");
					int bussSeats = rs.getInt("bussSeats");
					float bussSeatFare = rs.getFloat("bussSeatFare");
					int bussSeatsAvailable  = rs.getInt("bussSeatsAvailable");
					flightBean = new FlightInfoBean(flightNo, airline, depCity, arrCity,
														depDate, arrDate, depTime, arrTime,
														firstSeats, firstSeatFare, firstSeatsAvailable,
														bussSeats, bussSeatFare, bussSeatsAvailable);
									}
				} catch (SQLException e) {
					myLogger.error("Exception from  getFlightDetailsOnId()", e); //logger message
					throw new AirlineException("Problem in getFlightDetailsOnId(int flightNo)",e);
		} finally {
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					throw new AirlineException("Problem in closing Result Set", e);
				}
			}
		}
		return flightBean;
	}

	
	//get flight list on Date...executive service
	@Override
	public ArrayList<FlightInfoBean> getFlightList(LocalDate startDepDate,
			LocalDate endDepDate) throws AirlineException {
		
		ArrayList<FlightInfoBean> flightList = new ArrayList<>();
		FlightInfoBean flightBean = null;
		myLogger.info("Execution in getFlightList()."); //logger message
		String qry="SELECT * FROM flightInfo WHERE depDate BETWEEN ? AND ?";
		
		ResultSet rs = null;
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			){
					stmt.setDate(1, Date.valueOf(startDepDate));
					stmt.setDate(2, Date.valueOf(endDepDate));
					
					rs = stmt.executeQuery();
					myLogger.info("Query execution: "+ qry); //logger message
					while(rs.next()){
						
						int flightNo = rs.getInt("flightNo");
						String airline  = rs.getString("airline");
						String depCity = rs.getString("depCity"); 
						String arrCity = rs.getString("arrCity");
						LocalDate depDate = rs.getDate("depDate").toLocalDate();
						LocalDate arrDate = rs.getDate("arrDate").toLocalDate();
						String depTime = rs.getString("depTime");
						String arrTime = rs.getString("arrTime");
						int firstSeats = rs.getInt("firstSeats"); 
						float firstSeatFare = rs.getFloat("firstSeatFare");
						int firstSeatsAvailable = rs.getInt("firstSeatsAvailable");
						int bussSeats = rs.getInt("bussSeats");
						float bussSeatFare = rs.getFloat("bussSeatFare");
						int bussSeatsAvailable = rs.getInt("bussSeatsAvailable");
						
						flightBean = new FlightInfoBean(flightNo, airline, depCity, arrCity,
															depDate, arrDate, depTime, arrTime,
															firstSeats, firstSeatFare, firstSeatsAvailable,
															bussSeats, bussSeatFare, bussSeatsAvailable);
						
						flightList.add(flightBean);
					}
				} catch (SQLException e) {
					myLogger.error("Exception from  getFlightList()", e); //logger message
					throw new AirlineException("Problem in getFlightList() on Dates",e);
				} finally {
					if(rs!=null){
						try {
							rs.close();
						} catch (SQLException e) {
							throw new AirlineException("Problem in closing Result Set", e);
						}
					}
				}
					return flightList;
		}

	
	//remove flight on id...admin service
	@Override
	public boolean removeFlight(int flightNo) throws AirlineException {
		
		myLogger.info("Execution in removeFlight()."); //logger message
		String qry = "delete from flightInfo where flightNo=?";
		
		int recAffected = 0;
		
		try(PreparedStatement stmt = connect.prepareStatement(qry);
			){
				stmt.setInt(1, flightNo);
				recAffected = stmt.executeUpdate();
				myLogger.info("Query execution: "+ qry); //logger message
				
			} catch(Exception e){
				myLogger.error("Exception from  removeFlight()", e); //logger message
				throw new AirlineException("Problem in removeFlight()", e);
			}
			return recAffected > 0 ? true : false;
	}

	
	//update flight arrival time...admin 
	@Override
	public boolean updateArrTime(int flightNo, String arrTime)
			throws AirlineException {
		
		int recAffected = 0;
		
		myLogger.info("Execution in updateArrTime()."); //logger message
		
		String qry="update flightInfo set arrTime=? where flightNo=?";
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					stmt.setString(1, arrTime);
					stmt.setInt(2, flightNo);
					
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from updateArrTime() ", e); //logger message
				throw new AirlineException("Problem in updateArrTime()!!!", e);
		}
			return recAffected > 0 ? true : false;
		
	}
	
	//update flight departure time...admin 
	@Override
	public boolean updateDepTime(int flightNo, String depTime)
			throws AirlineException {
		
		int recAffected = 0;
		
		myLogger.info("Execution in updateDepTime()."); //logger message
		
		String qry="update flightInfo set depTime=? where flightNo=?";
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					stmt.setString(1, depTime);
					stmt.setInt(2, flightNo);
				
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from updateDepTime() ", e); //logger message
				throw new AirlineException("Problem in  updateDepTime()!!!", e);
		}
			return recAffected > 0 ? true : false;
	}

	
	//update flight arrival date...admin 
	@Override
	public boolean updateArrDate(int flightNo, LocalDate arrDate)
			throws AirlineException {

		int recAffected = 0;
		
		myLogger.info("Execution in updateArrDate()."); //logger message
		
		String qry="update flightInfo set arrDate=? where flightNo=?";
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					stmt.setDate(1, Date.valueOf(arrDate));
					stmt.setInt(2, flightNo);
					
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from  updateArrDate()", e); //logger message
				throw new AirlineException("Problem in  updateArrDate()!!!", e);
		}
			return recAffected > 0 ? true : false;
	}

	//update flight departure date...admin 
	@Override
	public boolean updateDepDate(int flightNo, LocalDate depDate)
			throws AirlineException {
		
		int recAffected = 0;
		
		myLogger.info("Execution in updateDepDate()."); //logger message
		
		String qry="update flightInfo set depDate=? where flightNo=?";
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					stmt.setDate(1, Date.valueOf(depDate));
					stmt.setInt(2, flightNo);
					
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from  updateDepDate()", e); //logger message
				throw new AirlineException("Problem in updateDepDate()!!!", e);
		}
			return recAffected > 0 ? true : false;
	}

	//update flight first class seats occupancy...admin 
	@Override
	public boolean updateFirstSeats(int flightNo, int firstSeats)
			throws AirlineException {
		
		int recAffected = 0;
		
		myLogger.info("Execution in updateFirstSeats()."); //logger message
		
		String qry="update flightInfo set firstSeats=? where flightNo=? ";
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					stmt.setInt(1, firstSeats);
					stmt.setInt(2, flightNo);
					
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from updateFirstSeats() ", e); //logger message
				throw new AirlineException("Problem in  updateFirstSeats()!!!", e);
		}
			return recAffected > 0 ? true : false;
	}

	//update flight business class seats occupancy...admin 
	@Override
	public boolean updateBussSeats(int flightNo, int bussSeats)
			throws AirlineException {
		
		int recAffected = 0;
		
		myLogger.info("Execution in updateBussSeats()."); //logger message
		
		String qry="update flightInfo set bussSeats=? where flightNo=?";
		
		try(PreparedStatement stmt=connect.prepareStatement(qry);)
				{
					stmt.setInt(1, bussSeats);
					stmt.setInt(2, flightNo);
				
					recAffected = stmt.executeUpdate();
					myLogger.info("Query execution: "+ qry); //logger message
				}
			catch (SQLException e) {	
				myLogger.error("Exception from updateBussSeats() ", e); //logger message
				throw new AirlineException("Problem in updateBussSeats()!!!", e);
		}
			return recAffected > 0 ? true : false;
	}

	
	

}
