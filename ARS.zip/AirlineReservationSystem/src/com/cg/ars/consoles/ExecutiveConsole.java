package com.cg.ars.consoles;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.exceptions.AirlineException;
import com.cg.ars.services.ExecuticeServiceImpl;
import com.cg.ars.services.ExecutiveService;

public class ExecutiveConsole {

	public static void getExecutiveConsole() {
		
		try{
		//creating executive service object
		ExecutiveService exService = new ExecuticeServiceImpl();
		
		Scanner kbdInput = new Scanner(System.in);
		
		//declare all variables globally here
		int choice = 0;
		int flightNo = 0;
		boolean flightNoValid = false;
		FlightInfoBean flightBean = null;
		String strDate = null;
		boolean strDateValid = false;
		DateTimeFormatter format = null;
		LocalDate startDepDate = null;
		LocalDate endDepDate = null;
		ArrayList<FlightInfoBean> flightList = null;
		
		do{
			System.out.println("******************************************");
			System.out.println("Welcome to Airline Reservation System.");
			System.out.println("******************************************");
			System.out.println("Menu...");
			System.out.println("1. View flight occupancy on a particular flight.");
			System.out.println("2. View flight occupancy over a period.");
			System.out.println("3. Log Out.");
			System.out.println("******************************************");
			
			do{
				System.out.println("Enter a choice");
				choice = kbdInput.nextInt();
				if(choice!=1 && choice!=2 && choice!=3){
					System.out.println("Enter valid choice");
				}
			}while(choice!=1 && choice!=2 && choice!=3);
			
			switch(choice){
			case 1: {
				//View flight occupancy on Id.
				do{
				System.out.println("Enter flight number.");
				flightNo = kbdInput.nextInt();
				flightNoValid = exService.validateFlightNo(flightNo);
				} while(!flightNoValid);
				
				flightBean = exService.viewFlightOccupancyOnId(flightNo);
				System.out.println("******************************************");
				System.out.println("Flight number: "+flightNo);
				System.out.println("Source : " + flightBean.getDepCity());
				System.out.println("Destination : " + flightBean.getArrCity());
				System.out.println("Capacity in Bussiness class: "+flightBean.getBussSeats());
				System.out.println("Available seats in Bussiness class: "+flightBean.getBussSeatsAvailable());
				System.out.println("Capacity in First class: "+flightBean.getFirstSeats());
				System.out.println("Available seats in First class: "+flightBean.getFirstSeatsAvailable());
				
				break;
			}//End of case 1, switch 1
			
			case 2: {
				//View flight occupancy on Date.
				
					do{System.out.println("Enter starting departure date");
					strDate = kbdInput.next();
					strDateValid = exService.validateStrDate(strDate);
					if(strDateValid == false){
						System.out.println("Enter date in format yyyy-mm-dd");
					}
					
					} while(!strDateValid);
					
					format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					startDepDate = LocalDate.parse(strDate, format);
				
					
				
				
			
					do{System.out.println("Enter ending departure date");
					strDate = kbdInput.next();
					strDateValid = exService.validateStrDate(strDate);
					if(strDateValid==false){
						System.out.println("Enter date in format yyyy-mm-dd");
					}
					
					} while(!strDateValid);
					
					format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					endDepDate = LocalDate.parse(strDate, format);
					
					
				
				
				flightList = exService.viewFlightOccupancyOnDate(startDepDate, endDepDate);
				for(FlightInfoBean flight : flightList)
				{
					System.out.println("******************************************");
					System.out.println("Flight number: "+flight.getFlightNo());
					System.out.println("Source : " + flight.getDepCity());
					System.out.println("Destination : " + flight.getArrCity());
					System.out.println("Capacity in Bussiness class: "+flight.getBussSeats());
					System.out.println("Available seats in Bussiness class: "+flight.getBussSeatsAvailable());
					System.out.println("Capacity in First class: "+flight.getFirstSeats());
					System.out.println("Available seats in First class: "+flight.getFirstSeatsAvailable());
					System.out.println("******************************************");
				}
								
				break;
			}//End of case 2, switch 1
			
			case 3: {
				//5. Exit.
				System.out.println("Logged Out successfully.");
				System.out.println("Thanks and visit again.");
				  
				break;	
			}//End of case 3, switch 1
			
			} //End of switch 1
			
		}//End of do
			while(choice != 3);
		
			}// End of try
			catch (AirlineException e) {
				e.printStackTrace();
		}//End of catch block
	
	}// End of Main

}// End of class
