package com.cg.ars.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.beans.UsersBean;
import com.cg.ars.daos.BookingInfoDao;
import com.cg.ars.daos.BookingInfoDaoImpl;
import com.cg.ars.daos.FlightInfoDao;
import com.cg.ars.daos.FlightInfoDaoImpl;
import com.cg.ars.daos.UsersDao;
import com.cg.ars.daos.UsersDaoImpl;
import com.cg.ars.exceptions.AirlineException;

public class ExecuticeServiceImpl implements ExecutiveService {

	//creating relevant dao reference instances
	private UsersDao usersDao;
	private FlightInfoDao flightInfoDao;
	static Logger myLogger = Logger.getLogger("myLogger");
	
	public ExecuticeServiceImpl() throws AirlineException {
		
		myLogger.info("Services: Dao injected."); 
		usersDao = new UsersDaoImpl();
		flightInfoDao = new FlightInfoDaoImpl();
	}
	
	//validate User...usersDao
	@Override
	public boolean validateUser(UsersBean usersBean) throws AirlineException {
		ArrayList<UsersBean> usersList = usersDao.getUsersList();
		boolean isExisting = usersList.contains(usersBean);

		return isExisting;
	}
	

	//validate FlightNo...flightInfoDao
	@Override
	public boolean validateFlightNo(int flightNo) throws AirlineException {
		
		FlightInfoBean flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
		
		if(flightBean != null){
			return true;
		}else{
			return false;
		}
		
	}
	
	//view flight occupancy on Id...flightInfoDao
	@Override
	public FlightInfoBean viewFlightOccupancyOnId(int flightNo)
			throws AirlineException {
		
		FlightInfoBean flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
		return flightBean;
	}

	//view flight occupancy on Date...flightInfoDao
	@Override
	public ArrayList<FlightInfoBean> viewFlightOccupancyOnDate(LocalDate startDepDate, LocalDate endDepDate)
			throws AirlineException {
		
		ArrayList<FlightInfoBean> flightList = flightInfoDao.getFlightList(startDepDate, endDepDate);
		return flightList;
	}


	//date pattern validation
	@Override
	public boolean validateStrDate(String strDate) throws AirlineException {
		
		try {
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(strDate, format);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	
	//validate Local DepDate...FlightInfoDao
	@Override
	public boolean validateDepDate(LocalDate depDate) throws AirlineException {
		
		ArrayList<LocalDate> depDateList = flightInfoDao.getDepDateList();
		boolean isExisting = depDateList.contains(depDate);
		
		return isExisting;
	}

}
