package com.cg.ars.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.ars.beans.BookingInfoBean;
import com.cg.ars.beans.FlightInfoBean;
import com.cg.ars.beans.UsersBean;
import com.cg.ars.daos.BookingInfoDao;
import com.cg.ars.daos.BookingInfoDaoImpl;
import com.cg.ars.daos.FlightInfoDao;
import com.cg.ars.daos.FlightInfoDaoImpl;
import com.cg.ars.daos.UsersDao;
import com.cg.ars.daos.UsersDaoImpl;
import com.cg.ars.exceptions.AirlineException;

public class UserServiceImpl implements UserService{
	
	//creating relevant dao reference instances
	private UsersDao usersDao;
	private FlightInfoDao flightInfoDao;
	private BookingInfoDao bookingInfoDao;
	static Logger myLogger = Logger.getLogger("myLogger");
	
	
	//constructor
	public UserServiceImpl() throws AirlineException{
		
		myLogger.info("Services: Dao injected."); 
		usersDao = new UsersDaoImpl();
		flightInfoDao = new FlightInfoDaoImpl();
		bookingInfoDao = new BookingInfoDaoImpl();
	}

	@Override
	public boolean validateCity(String city) throws AirlineException {
		
		Pattern pt = Pattern.compile("[A-Z][a-z]*");
		Matcher match = pt.matcher(city);
		boolean patternMatch =  match.matches();
		
		return patternMatch;
	}
	
	
	//validate User...usersDao
	@Override
	public boolean validateUser(UsersBean usersBean) throws AirlineException {
		
		ArrayList<UsersBean> usersList = usersDao.getUsersList();
		boolean isExisting = usersList.contains(usersBean);
		
		return isExisting;
	}

	
	//validateDepCity...flightInfoDao
	@Override
	public boolean validateDepCity(String depCity) throws AirlineException {
		ArrayList<String> depCityList = flightInfoDao.getDepCityList();
		boolean isExisting = depCityList.contains(depCity);
		
		return isExisting;
	}

	
	//validateArrCity...flightInfoDao
	@Override
	public boolean validateArrCity(String arrCity) throws AirlineException {
		
		ArrayList<String> arrCityList = flightInfoDao.getArrCityList();
		boolean isExisting = arrCityList.contains(arrCity);
		
		return isExisting;
	}
	
	//date pattern validation
	@Override
	public boolean validateStrDate(String strDate) throws AirlineException {
		
		try {
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(strDate, format);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	
	//validateDepDate...flightInfoDao
	@Override
	public boolean validateDepDate(LocalDate depDate) throws AirlineException {
		
		ArrayList<LocalDate> depDateList = flightInfoDao.getDepDateList();
		boolean isExisting = depDateList.contains(depDate);
		
		return isExisting;
	}

	
	//view Flight List...flightInfoDao
	@Override
	public ArrayList<FlightInfoBean> viewFlightList(String depCity,
			String arrCity, LocalDate depDate) throws AirlineException {

		ArrayList<FlightInfoBean> flightList = flightInfoDao.getFlightList(depCity, arrCity, depDate);
		return flightList;
	}

	
	
	//validate FlightNo...flightInfoDao
	@Override
	public boolean validateFlightNo(int flightNo) throws AirlineException {
		
		FlightInfoBean flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
		
		if(flightBean != null){
			return true;
		}else{
			return false;
		}
		
	}

	//validate NoOfPassengers...flightInfoDao
	@Override
	public boolean validateNoOfPassengers(int flightNo, String classType, int noOfPassengers)
			throws AirlineException {
		
		boolean isValid = false;
		
		FlightInfoBean flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
		
		//for business classType
		if("BUSINESS".equals(classType)){
			
			if(noOfPassengers <= flightBean.getBussSeatsAvailable() && noOfPassengers > 0){
				isValid = true;
			} else{
				isValid = false;
			}
		}
		//for first classType
			else if("FIRST".equals(classType)){
			if(noOfPassengers <= flightBean.getFirstSeatsAvailable() && noOfPassengers > 0){
				isValid = true;
			} else{
				isValid = false;
			}
		}
		return isValid;
	}

	
	//generate Total Fare...userService
	@Override
	public float generateTotalFare(int flightNo, String classType,
			int noOfPassengers) throws AirlineException {
		
		float baseFare = 0;
		float totalFare = 0;
		FlightInfoBean flightBean = new FlightInfoBean();
		
		try {
			flightBean = flightInfoDao.getFlightDetailsOnId(flightNo);
			
			if("FIRST".equals(classType)){
				baseFare = flightBean.getFirstSeatFare();
			}
			else if("BUSINESS".equals(classType)){
				baseFare = flightBean.getBussSeatFare();
			}
			else{
				throw new AirlineException("Not a correct class type.");
			}
			totalFare = baseFare * noOfPassengers;
			
		} catch (AirlineException e) {
			throw new AirlineException("Problem in generating fare", e);
		}
		return totalFare;
	
	}

	//validate custEmail via pattern matching...client side validation
	@Override
	public boolean validateCustEmail(String custEmail) throws AirlineException {
		
		Pattern pt = Pattern.compile("[a-zA-z0-9._]+@[a-z0-9.-]+[.][a-z]{2,3}");
		Matcher match = pt.matcher(custEmail);
		if(match.matches()){
			return true;
		}	else{
		return false;
		}
	}

	//validate creditCardInfo via pattern matching...client side validation
	@Override
	public boolean validateCreditCardInfo(String creditCardInfo)
			throws AirlineException {
		
		Pattern pt = Pattern.compile("[0-9]{16}");
		Matcher match = pt.matcher(creditCardInfo);
		boolean patternMatch =  match.matches();
		
		return patternMatch;
	}
	
	
	//bookFlight...insert into BookingInfodao and update FlightInfoDao
	@Override
	public int bookFlight(int flightNo, BookingInfoBean bookingInfoBean) throws AirlineException {
		
		//insert
		int bookingId = bookingInfoDao.createNewBooking(bookingInfoBean);
		
		//update seats
		String classType = bookingInfoBean.getClassType();
		int noOfPassengers = bookingInfoBean.getNoOfPassengers();
		boolean isUpdateSucc = flightInfoDao.updateSeatsOnBooking(flightNo, classType, noOfPassengers);
		
		if(isUpdateSucc == true){
			return bookingId;
			}
		else{
			throw new AirlineException("Probelm in booking ticket");
		}
		}

	//validate bookingId...BookingInfoDao
	@Override
	public boolean validateBookingId(int bookingId) throws AirlineException {
		
		BookingInfoBean bookingBean = bookingInfoDao.getBookingOnId(bookingId);
		if(bookingBean != null){
			return true;
		}else{
			return false;
		}
		
	}

	//getBookingOnId...BookingInfoDao
	@Override
	public BookingInfoBean viewBookingOnId(int bookingId)
			throws AirlineException {
		
		BookingInfoBean bookingBean = bookingInfoDao.getBookingOnId(bookingId);
			return bookingBean;
	}

	//cancelBookingOnId...delete from BookingInfoDao and update FlightInfoDao
	@Override
	public boolean cancelBookingOnId(int bookingId) throws AirlineException {
		
		//get booking details on id
		BookingInfoBean bookingBean = bookingInfoDao.getBookingOnId(bookingId);
		int flightNo = bookingBean.getFlightNo();
		String classType = bookingBean.getClassType();
		int noOfPassengers = bookingBean.getNoOfPassengers();
		
		//update seats in FlightInfoDao
		boolean isUpdateSucc = flightInfoDao.updateSeatsOnCancellation(flightNo, classType, noOfPassengers);
		
		if(isUpdateSucc){
			//remove booking
			boolean isBookingCancelled = bookingInfoDao.removeBookingOnId(bookingId);	
			return isBookingCancelled;
		}
		else{
			throw new AirlineException("Probelm in cancelling booking");
		}
	}


	
	
}
